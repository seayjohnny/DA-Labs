package edu.tarleton.seay.lab6;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "BookServlet", urlPatterns = {"/BookController"})
public class BookServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        ServletContext sc = request.getServletContext();
        List<Book> books = (List<Book>)sc.getAttribute("books");
                
        Boolean add = Boolean.parseBoolean(request.getParameter("add"));
        if(add)
        {
            String title = request.getParameter("title");
            String author = request.getParameter("author");
            String year = request.getParameter("year");
            String pages = request.getParameter("pages");
            String price = request.getParameter("price");
            Book book = new Book(title, author, year, pages, price);
        
            books.add(book);
        }
        
        else
        {
            String uuid = request.getParameter("uuid");
            int bookToRemove = -1;
            
            for (int i = 0; i < books.size(); i++) {
                if(books.get(i).uuid.equals(uuid))
                {
                    bookToRemove = i;
                }
            }
            
            books.remove(bookToRemove);
        }
        
        response.sendRedirect("index.jsp");
    }
}