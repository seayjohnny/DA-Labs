package edu.tarleton.seay.lab6;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class BookServletListener implements ServletContextListener {

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        
        ServletContext sc = sce.getServletContext();
        List<Book> books = Collections.synchronizedList(new ArrayList<Book>());
        sc.setAttribute("books", books);
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
    }
}