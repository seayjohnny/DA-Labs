
package edu.tarleton.seay.lab6;

import java.util.UUID;

public class Book {
    public String uuid;
    public String title;
    public String author;
    public String year;
    public String pages;
    public String price;

    public Book(String title, String author, String year, String pages, String price) {
        this.uuid = UUID.randomUUID().toString();
        this.title = title.isEmpty() ? "n/a" : title;
        this.author = author.isEmpty() ? "n/a" : author;
        this.year = year.isEmpty() ? "n/a" : year;
        this.pages = pages.isEmpty() ? "n/a" : pages;
        this.price = price.isEmpty() ? "n/a" : price;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getPages() {
        return pages;
    }

    public void setPages(String pages) {
        this.pages = pages;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }
}